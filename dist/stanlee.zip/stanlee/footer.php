<?
/**
 * @author      Flurin Dürst
 * @version     1.8
 * @since       WPSeed 0.1
 */
?>

    <footer class="footer">
      <div class="inner">Lorem Ipsum dolor sit amet</div>
    </footer>

    <? wp_footer() ?>
  </body>
</html>
